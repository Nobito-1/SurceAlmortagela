return {
Token = "5779418129:AAHOxzqBsMmPWzAWLyOKwGmLmX4bqXT8HSY",
UserBot = "MkAlmortagel_bot",
UserSudo = "AlmortagelTech",
SudoId = 5779418129}
